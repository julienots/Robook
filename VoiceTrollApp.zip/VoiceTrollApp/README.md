# VoiceTroll

App Android (Kotlin) qui enregistre une empreinte vocale, la reconnaît en
arrière-plan, et joue un son / affiche un texte quand la personne parle —
avec un programme horaire par profil.

## ⚠️ Important — consentement

Cette app fait tourner le micro en tâche de fond. Pour rester dans les
clous (et parce qu'Android l'exige de toute façon à partir d'Android 9+),
elle affiche **en permanence une notification visible** tant qu'elle
écoute, avec un bouton "Arrêter". N'installe pas ça sur le téléphone de
quelqu'un sans son accord — utilise-la sur ton propre téléphone, pour un
troll entre amis consentants (ex: une soirée où tout le monde sait que le
jeu tourne).

## Comment ça marche

1. **Enrôlement** : tu enregistres ~10 secondes de la voix d'une personne
   depuis l'écran "Ajouter une voix". L'app calcule une empreinte
   vocale (analyse spectrale par bandes Mel, calculée entièrement sur
   l'appareil, sans connexion internet ni service tiers).
2. **Programme** : pour chaque profil, tu peux définir une heure de début,
   une durée d'activation, et si ça se répète chaque jour.
3. **Écoute** : quand tu actives l'écoute globale, un service premier plan
   tourne (notification visible obligatoire) et compare en continu la
   voix captée aux empreintes enregistrées.
4. **Déclenchement** : si une voix correspond à un profil actif dans sa
   plage horaire, l'app joue le fichier son que tu as assigné et/ou
   affiche une notification avec ton texte.

## ⚠️ Limites techniques (à savoir avant de t'en servir)

La reconnaissance vocale ici est "maison" (bandes Mel + similarité
cosinus), volontairement simple pour rester 100% embarquée sans modèle
téléchargé. Ce n'est **pas** un système biométrique de qualité
industrielle :
- Elle marche mieux avec un enregistrement d'enrôlement propre (peu de
  bruit de fond, la personne qui parle normalement pendant les 10s).
- Un environnement bruyant ou une voix très proche peut donner des faux
  positifs/négatifs. Le seuil de similarité est réglable dans
  `VoiceMatcher.DEFAULT_THRESHOLD` (`app/src/main/java/com/voicetroll/app/audio/VoiceMatcher.kt`).
- Si les résultats ne sont pas bons, réenregistre l'échantillon dans un
  environnement plus calme.

## Compiler l'APK via GitHub Actions

1. Crée un nouveau dépôt GitHub et pousse ce dossier tel quel :
   ```bash
   cd VoiceTrollApp
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<ton-user>/<ton-repo>.git
   git push -u origin main
   ```
2. Va dans l'onglet **Actions** de ton dépôt GitHub : le workflow
   `Build APK` se lance automatiquement au push (ou lance-le manuellement
   via "Run workflow").
3. Une fois le job terminé, ouvre le run et télécharge l'artifact
   **VoiceTroll-debug-apk** dans la section "Artifacts" — c'est ton
   fichier `app-debug.apk`.
4. Transfère l'APK sur ton téléphone Android et installe-le (autorise
   l'installation depuis une source inconnue si demandé).

Aucune clé de signature n'est nécessaire pour cet APK debug — il est
directement installable pour un usage perso, mais pas destiné à être
publié sur le Play Store en l'état.

## Structure du projet

```
app/src/main/java/com/voicetroll/app/
  MainActivity.kt              écran principal (liste des profils, start/stop)
  VoiceListenerService.kt      service premier plan qui écoute en arrière-plan
  db/                          Room : profils vocaux stockés en base
  audio/                       extraction de caractéristiques vocales + comparaison
  util/ScheduleUtil.kt         logique des créneaux horaires
  ui/AddProfileActivity.kt     enrôlement d'une nouvelle voix + choix du son
  ui/ScheduleActivity.kt       réglage de l'heure/durée par profil
```
