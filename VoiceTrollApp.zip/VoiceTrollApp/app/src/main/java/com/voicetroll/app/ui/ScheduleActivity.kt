package com.voicetroll.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.voicetroll.app.databinding.ActivityScheduleBinding
import com.voicetroll.app.db.AppDatabase
import kotlinx.coroutines.launch

class ScheduleActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROFILE_ID = "profile_id"
    }

    private lateinit var binding: ActivityScheduleBinding
    private var profileId: Long = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityScheduleBinding.inflate(layoutInflater)
        setContentView(binding.root)

        profileId = intent.getLongExtra(EXTRA_PROFILE_ID, -1)
        if (profileId < 0) { finish(); return }

        lifecycleScope.launch {
            val dao = AppDatabase.get(applicationContext).voiceProfileDao()
            val profile = dao.getById(profileId) ?: return@launch

            if (profile.scheduleStartMinute >= 0) {
                binding.timePickerStart.hour = profile.scheduleStartMinute / 60
                binding.timePickerStart.minute = profile.scheduleStartMinute % 60
            }
            if (profile.durationMinutes > 0) {
                binding.editDurationMinutes.setText(profile.durationMinutes.toString())
            }
            binding.checkRepeatDaily.isChecked = profile.repeatDaily
        }

        binding.btnSaveSchedule.setOnClickListener { save() }
    }

    private fun save() {
        val startMinute = binding.timePickerStart.hour * 60 + binding.timePickerStart.minute
        val duration = binding.editDurationMinutes.text.toString().toIntOrNull() ?: 0
        val repeat = binding.checkRepeatDaily.isChecked

        lifecycleScope.launch {
            val dao = AppDatabase.get(applicationContext).voiceProfileDao()
            val profile = dao.getById(profileId) ?: return@launch
            dao.update(
                profile.copy(
                    scheduleStartMinute = startMinute,
                    durationMinutes = duration,
                    repeatDaily = repeat
                )
            )
            Toast.makeText(this@ScheduleActivity, "Programme enregistré", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
