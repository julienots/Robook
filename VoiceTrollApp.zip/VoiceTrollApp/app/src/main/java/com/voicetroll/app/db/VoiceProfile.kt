package com.voicetroll.app.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Un profil = une personne enregistrée.
 *
 * - embedding : empreinte vocale moyenne calculée à l'enrôlement (voir MfccExtractor)
 * - soundFilePath : fichier audio local copié dans le stockage interne de l'app,
 *   joué quand la voix est reconnue
 * - scheduleStartMinute : minute de la journée (0-1439) à laquelle le programme démarre,
 *   -1 = pas de restriction horaire (actif dès que l'écoute globale est activée)
 * - durationMinutes : combien de temps après scheduleStartMinute le profil reste actif,
 *   0 = toute la journée
 */
@Entity(tableName = "voice_profiles")
data class VoiceProfile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val embedding: FloatArray,
    val soundFilePath: String?,
    val responseText: String?,
    val enabled: Boolean = true,
    val scheduleStartMinute: Int = -1,
    val durationMinutes: Int = 0,
    val repeatDaily: Boolean = true
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is VoiceProfile) return false
        return id == other.id
    }

    override fun hashCode(): Int = id.hashCode()
}
