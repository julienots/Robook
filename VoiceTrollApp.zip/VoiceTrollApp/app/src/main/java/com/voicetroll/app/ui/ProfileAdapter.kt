package com.voicetroll.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.voicetroll.app.databinding.ItemProfileBinding
import com.voicetroll.app.db.VoiceProfile
import com.voicetroll.app.util.ScheduleUtil

class ProfileAdapter(
    private val onToggle: (VoiceProfile, Boolean) -> Unit,
    private val onSchedule: (VoiceProfile) -> Unit,
    private val onDelete: (VoiceProfile) -> Unit
) : ListAdapter<VoiceProfile, ProfileAdapter.VH>(DIFF) {

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<VoiceProfile>() {
            override fun areItemsTheSame(a: VoiceProfile, b: VoiceProfile) = a.id == b.id
            override fun areContentsTheSame(a: VoiceProfile, b: VoiceProfile) = a == b
        }
    }

    inner class VH(val binding: ItemProfileBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemProfileBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val profile = getItem(position)
        holder.binding.profileName.text = profile.name
        holder.binding.profileSchedule.text = ScheduleUtil.describeSchedule(profile)

        holder.binding.profileEnabledSwitch.setOnCheckedChangeListener(null)
        holder.binding.profileEnabledSwitch.isChecked = profile.enabled
        holder.binding.profileEnabledSwitch.setOnCheckedChangeListener { _, checked ->
            onToggle(profile, checked)
        }

        holder.binding.profileScheduleBtn.setOnClickListener { onSchedule(profile) }
        holder.binding.profileDeleteBtn.setOnClickListener { onDelete(profile) }
    }
}
