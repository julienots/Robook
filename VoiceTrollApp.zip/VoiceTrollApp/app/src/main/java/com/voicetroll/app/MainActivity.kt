package com.voicetroll.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.voicetroll.app.databinding.ActivityMainBinding
import com.voicetroll.app.db.AppDatabase
import com.voicetroll.app.db.VoiceProfile
import com.voicetroll.app.ui.AddProfileActivity
import com.voicetroll.app.ui.ProfileAdapter
import com.voicetroll.app.ui.ScheduleActivity
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: ProfileAdapter
    private var listening = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startListeningService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = ProfileAdapter(
            onToggle = { profile, checked -> updateProfile(profile.copy(enabled = checked)) },
            onSchedule = { profile ->
                startActivity(
                    Intent(this, ScheduleActivity::class.java)
                        .putExtra(ScheduleActivity.EXTRA_PROFILE_ID, profile.id)
                )
            },
            onDelete = { profile -> deleteProfile(profile) }
        )
        binding.profileList.layoutManager = LinearLayoutManager(this)
        binding.profileList.adapter = adapter

        binding.btnAddProfile.setOnClickListener {
            startActivity(Intent(this, AddProfileActivity::class.java))
        }

        binding.btnToggleListening.setOnClickListener {
            if (listening) stopListeningService() else requestPermissionsAndStart()
        }

        lifecycleScope.launch {
            AppDatabase.get(applicationContext).voiceProfileDao().observeAll()
                .collect { adapter.submitList(it) }
        }

        updateStatusUi(false)
    }

    private fun requestPermissionsAndStart() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) {
            startListeningService()
        } else {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun startListeningService() {
        val intent = Intent(this, VoiceListenerService::class.java)
        ContextCompat.startForegroundService(this, intent)
        listening = true
        updateStatusUi(true)
    }

    private fun stopListeningService() {
        val intent = Intent(this, VoiceListenerService::class.java).apply {
            action = VoiceListenerService.ACTION_STOP
        }
        startService(intent)
        listening = false
        updateStatusUi(false)
    }

    private fun updateStatusUi(active: Boolean) {
        binding.statusText.text = if (active) "Écoute : active (arrière-plan)" else "Écoute : inactive"
        binding.btnToggleListening.text = getString(
            if (active) R.string.btn_stop else R.string.btn_start
        )
    }

    private fun updateProfile(profile: VoiceProfile) {
        lifecycleScope.launch {
            AppDatabase.get(applicationContext).voiceProfileDao().update(profile)
        }
    }

    private fun deleteProfile(profile: VoiceProfile) {
        lifecycleScope.launch {
            AppDatabase.get(applicationContext).voiceProfileDao().delete(profile)
        }
    }
}
