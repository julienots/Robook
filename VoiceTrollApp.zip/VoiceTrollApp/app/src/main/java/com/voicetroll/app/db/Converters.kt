package com.voicetroll.app.db

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromFloatArray(value: FloatArray): String =
        value.joinToString(",")

    @TypeConverter
    fun toFloatArray(value: String): FloatArray =
        if (value.isBlank()) FloatArray(0)
        else value.split(",").map { it.toFloat() }.toFloatArray()
}
