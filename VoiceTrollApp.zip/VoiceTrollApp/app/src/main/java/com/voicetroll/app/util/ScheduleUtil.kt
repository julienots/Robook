package com.voicetroll.app.util

import com.voicetroll.app.db.VoiceProfile
import java.util.Calendar

object ScheduleUtil {

    /** Vrai si, à l'instant présent, le programme du profil doit être actif. */
    fun isActiveNow(profile: VoiceProfile): Boolean {
        if (!profile.enabled) return false
        if (profile.scheduleStartMinute < 0) return true // pas de restriction horaire

        val cal = Calendar.getInstance()
        val nowMinute = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)

        val start = profile.scheduleStartMinute
        val duration = profile.durationMinutes
        if (duration <= 0) {
            // Pas de durée précisée : actif toute la journée à partir de l'heure de début
            return nowMinute >= start
        }

        val end = start + duration
        return if (end <= 1440) {
            nowMinute in start until end
        } else {
            // La plage traverse minuit
            nowMinute >= start || nowMinute < (end - 1440)
        }
    }

    fun describeSchedule(profile: VoiceProfile): String {
        if (profile.scheduleStartMinute < 0) return "Toujours actif"
        val h = profile.scheduleStartMinute / 60
        val m = profile.scheduleStartMinute % 60
        val startStr = String.format("%02d:%02d", h, m)
        return if (profile.durationMinutes <= 0) {
            "Actif dès $startStr"
        } else {
            "Actif $startStr pendant ${profile.durationMinutes} min" +
                if (profile.repeatDaily) " (chaque jour)" else ""
        }
    }
}
