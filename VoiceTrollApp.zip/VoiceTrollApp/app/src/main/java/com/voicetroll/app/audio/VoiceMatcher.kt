package com.voicetroll.app.audio

import kotlin.math.sqrt

object VoiceMatcher {

    /** Seuil de similarité au-delà duquel on considère que c'est la même voix.
     *  À ajuster : plus bas = plus permissif (plus de faux positifs),
     *  plus haut = plus strict (plus de faux négatifs). */
    const val DEFAULT_THRESHOLD = 0.86f

    fun cosineSimilarity(a: FloatArray, b: FloatArray): Float {
        if (a.isEmpty() || b.isEmpty() || a.size != b.size) return -1f
        var dot = 0f
        var normA = 0f
        var normB = 0f
        for (i in a.indices) {
            dot += a[i] * b[i]
            normA += a[i] * a[i]
            normB += b[i] * b[i]
        }
        if (normA <= 0f || normB <= 0f) return -1f
        return dot / (sqrt(normA) * sqrt(normB))
    }

    /** Retourne le profil le plus proche (indice) si sa similarité dépasse le seuil, sinon -1. */
    fun findBestMatch(
        sample: FloatArray,
        candidates: List<FloatArray>,
        threshold: Float = DEFAULT_THRESHOLD
    ): Int {
        var bestIdx = -1
        var bestScore = threshold
        for (i in candidates.indices) {
            val score = cosineSimilarity(sample, candidates[i])
            if (score > bestScore) {
                bestScore = score
                bestIdx = i
            }
        }
        return bestIdx
    }
}
