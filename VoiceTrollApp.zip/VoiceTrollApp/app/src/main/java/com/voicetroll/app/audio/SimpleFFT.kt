package com.voicetroll.app.audio

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * FFT radix-2 basique (Cooley-Tukey), sans dépendance externe.
 * `size` doit être une puissance de 2.
 */
object SimpleFFT {

    fun magnitudeSpectrum(real: FloatArray): FloatArray {
        val n = real.size
        require(n and (n - 1) == 0) { "La taille doit être une puissance de 2" }

        val re = DoubleArray(n) { real[it].toDouble() }
        val im = DoubleArray(n)

        fft(re, im)

        val half = n / 2
        val mags = FloatArray(half)
        for (i in 0 until half) {
            val r = re[i]
            val imag = im[i]
            mags[i] = kotlin.math.sqrt(r * r + imag * imag).toFloat()
        }
        return mags
    }

    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = re.size
        if (n <= 1) return

        // Bit-reversal permutation
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) {
                j = j xor bit
                bit = bit shr 1
            }
            j = j or bit
            if (i < j) {
                var tmp = re[i]; re[i] = re[j]; re[j] = tmp
                tmp = im[i]; im[i] = im[j]; im[j] = tmp
            }
        }

        var len = 2
        while (len <= n) {
            val ang = -2 * PI / len
            val wReal = cos(ang)
            val wImag = sin(ang)
            var i = 0
            while (i < n) {
                var curReal = 1.0
                var curImag = 0.0
                for (k in 0 until len / 2) {
                    val evenIdx = i + k
                    val oddIdx = i + k + len / 2

                    val tReal = re[oddIdx] * curReal - im[oddIdx] * curImag
                    val tImag = re[oddIdx] * curImag + im[oddIdx] * curReal

                    re[oddIdx] = re[evenIdx] - tReal
                    im[oddIdx] = im[evenIdx] - tImag
                    re[evenIdx] += tReal
                    im[evenIdx] += tImag

                    val nextReal = curReal * wReal - curImag * wImag
                    val nextImag = curReal * wImag + curImag * wReal
                    curReal = nextReal
                    curImag = nextImag
                }
                i += len
            }
            len = len shl 1
        }
    }
}
