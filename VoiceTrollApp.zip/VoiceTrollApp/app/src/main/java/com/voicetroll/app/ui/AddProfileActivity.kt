package com.voicetroll.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.voicetroll.app.audio.VoiceFeatureExtractor
import com.voicetroll.app.databinding.ActivityAddProfileBinding
import com.voicetroll.app.db.AppDatabase
import com.voicetroll.app.db.VoiceProfile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class AddProfileActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddProfileBinding
    private var recordedEmbedding: FloatArray? = null
    private var pickedSoundPath: String? = null
    private var isRecording = false

    private val recordPermLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) doRecord() }

    private val pickSoundLauncher = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? -> uri?.let { copySoundToInternalStorage(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRecord.setOnClickListener {
            if (isRecording) return@setOnClickListener
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED
            ) {
                doRecord()
            } else {
                recordPermLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }

        binding.btnPickSound.setOnClickListener {
            pickSoundLauncher.launch("audio/*")
        }

        binding.btnSaveProfile.setOnClickListener { saveProfile() }
    }

    /** Enregistre ~10 secondes de voix et calcule l'empreinte vocale moyenne. */
    private fun doRecord() {
        isRecording = true
        binding.recordStatus.text = "Enregistrement en cours... parlez normalement pendant 10s"
        binding.btnRecord.isEnabled = false

        lifecycleScope.launch(Dispatchers.IO) {
            val sampleRate = VoiceFeatureExtractor.SAMPLE_RATE
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val totalSamples = sampleRate * 10 // 10 secondes
            val pcm = ShortArray(totalSamples)

            val recorder = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, 4096)
            )

            try {
                recorder.startRecording()
                var offset = 0
                while (offset < totalSamples) {
                    val read = recorder.read(pcm, offset, totalSamples - offset)
                    if (read > 0) offset += read else break
                }
            } finally {
                recorder.stop()
                recorder.release()
            }

            val embedding = VoiceFeatureExtractor.extractAverageEmbedding(pcm)

            withContext(Dispatchers.Main) {
                recordedEmbedding = embedding
                binding.recordStatus.text = "✅ Échantillon enregistré (10s)"
                binding.btnRecord.isEnabled = true
                isRecording = false
            }
        }
    }

    private fun copySoundToInternalStorage(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: return
            val outFile = File(filesDir, "sound_${System.currentTimeMillis()}.audio")
            FileOutputStream(outFile).use { out -> input.copyTo(out) }
            input.close()
            pickedSoundPath = outFile.absolutePath
            binding.soundStatus.text = "✅ Son sélectionné"
        } catch (e: Exception) {
            Toast.makeText(this, "Impossible de lire ce fichier audio", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveProfile() {
        val name = binding.editName.text.toString().trim()
        val embedding = recordedEmbedding

        if (name.isEmpty()) {
            Toast.makeText(this, "Indique un nom", Toast.LENGTH_SHORT).show()
            return
        }
        if (embedding == null) {
            Toast.makeText(this, "Enregistre d'abord un échantillon de voix", Toast.LENGTH_SHORT).show()
            return
        }

        val responseText = binding.editResponseText.text.toString().trim().ifEmpty { null }

        val profile = VoiceProfile(
            name = name,
            embedding = embedding,
            soundFilePath = pickedSoundPath,
            responseText = responseText
        )

        lifecycleScope.launch {
            AppDatabase.get(applicationContext).voiceProfileDao().insert(profile)
            Toast.makeText(this@AddProfileActivity, "Profil « $name » créé", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
