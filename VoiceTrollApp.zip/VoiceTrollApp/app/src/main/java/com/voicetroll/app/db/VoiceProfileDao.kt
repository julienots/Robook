package com.voicetroll.app.db

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface VoiceProfileDao {

    @Query("SELECT * FROM voice_profiles ORDER BY name ASC")
    fun observeAll(): Flow<List<VoiceProfile>>

    @Query("SELECT * FROM voice_profiles WHERE enabled = 1")
    suspend fun getEnabled(): List<VoiceProfile>

    @Query("SELECT * FROM voice_profiles WHERE id = :id")
    suspend fun getById(id: Long): VoiceProfile?

    @Insert
    suspend fun insert(profile: VoiceProfile): Long

    @Update
    suspend fun update(profile: VoiceProfile)

    @Delete
    suspend fun delete(profile: VoiceProfile)
}
