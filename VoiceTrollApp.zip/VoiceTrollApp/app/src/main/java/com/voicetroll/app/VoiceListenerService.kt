package com.voicetroll.app

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.voicetroll.app.audio.VoiceFeatureExtractor
import com.voicetroll.app.audio.VoiceMatcher
import com.voicetroll.app.db.AppDatabase
import com.voicetroll.app.db.VoiceProfile
import com.voicetroll.app.util.ScheduleUtil
import kotlinx.coroutines.*

/**
 * Service premier plan (foreground service) : c'est ce qui permet à l'écoute
 * de continuer même quand l'app est fermée / en arrière-plan. Android exige
 * une notification persistante et visible tant que ce service tourne — il
 * n'y a aucun moyen de contourner ça légitimement, et c'est volontaire ici :
 * la personne qui a l'app sur son téléphone doit toujours pouvoir voir que
 * le micro est utilisé.
 */
class VoiceListenerService : Service() {

    companion object {
        const val CHANNEL_ID = "voicetroll_listening"
        const val NOTIF_ID = 1
        const val ACTION_STOP = "com.voicetroll.app.STOP"

        private const val CHUNK_SECONDS = 1.5
    }

    private var audioRecord: AudioRecord? = null
    private var recordingJob: Job? = null
    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    private var mediaPlayer: MediaPlayer? = null
    private val lastTriggerAtMs = HashMap<Long, Long>()
    private val cooldownMs = 15_000L // évite de spammer le même profil en boucle

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopListening()
            stopSelf()
            return START_NOT_STICKY
        }

        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIF_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIF_ID, notification)
        }
        startListening()
        return START_STICKY // Android relance le service si le système le tue
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        stopListening()
        serviceScope.cancel()
    }

    private fun startListening() {
        if (recordingJob?.isActive == true) return

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            stopSelf()
            return
        }

        val sampleRate = VoiceFeatureExtractor.SAMPLE_RATE
        val minBufSize = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val chunkSamples = (sampleRate * CHUNK_SECONDS).toInt()
        val bufferSize = maxOf(minBufSize, chunkSamples * 2)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )

        val record = audioRecord ?: return
        if (record.state != AudioRecord.STATE_INITIALIZED) return

        record.startRecording()

        recordingJob = serviceScope.launch {
            val chunk = ShortArray(chunkSamples)
            val dao = AppDatabase.get(applicationContext).voiceProfileDao()

            while (isActive) {
                var offset = 0
                while (offset < chunk.size && isActive) {
                    val read = record.read(chunk, offset, chunk.size - offset)
                    if (read > 0) offset += read else break
                }
                if (!isActive) break

                if (!VoiceFeatureExtractor.isSpeech(chunk)) continue

                val embedding = VoiceFeatureExtractor.extractAverageEmbedding(chunk)
                val profiles = dao.getEnabled().filter { ScheduleUtil.isActiveNow(it) }
                if (profiles.isEmpty()) continue

                val bestIdx = VoiceMatcher.findBestMatch(
                    embedding,
                    profiles.map { it.embedding }
                )
                if (bestIdx >= 0) {
                    val matched = profiles[bestIdx]
                    triggerResponse(matched)
                }
            }
        }
    }

    private fun triggerResponse(profile: VoiceProfile) {
        val now = System.currentTimeMillis()
        val last = lastTriggerAtMs[profile.id] ?: 0L
        if (now - last < cooldownMs) return
        lastTriggerAtMs[profile.id] = now

        // Joue le son assigné, s'il y en a un
        profile.soundFilePath?.let { path ->
            try {
                mediaPlayer?.release()
                mediaPlayer = MediaPlayer().apply {
                    setDataSource(path)
                    prepare()
                    start()
                }
            } catch (_: Exception) {
                // fichier introuvable / illisible : on ignore silencieusement
            }
        }

        // Affiche une notification avec le texte personnalisé, si défini
        if (!profile.responseText.isNullOrBlank()) {
            showTriggerNotification(profile)
        }
    }

    private fun showTriggerNotification(profile: VoiceProfile) {
        val notif = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Voix reconnue : ${profile.name}")
            .setContentText(profile.responseText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(profile.id.toInt() + 1000, notif)
    }

    private fun stopListening() {
        recordingJob?.cancel()
        recordingJob = null
        audioRecord?.let {
            try {
                if (it.state == AudioRecord.STATE_INITIALIZED) it.stop()
            } catch (_: Exception) {
            }
            it.release()
        }
        audioRecord = null
        mediaPlayer?.release()
        mediaPlayer = null
    }

    private fun buildNotification(): Notification {
        val stopIntent = Intent(this, VoiceListenerService::class.java).apply { action = ACTION_STOP }
        val stopPending = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val openIntent = Intent(this, MainActivity::class.java)
        val openPending = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_listening_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openPending)
            .addAction(0, "Arrêter", stopPending)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
