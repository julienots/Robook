package com.voicetroll.app.audio

import kotlin.math.*

/**
 * Extraction de caractéristiques vocales "maison", sans modèle ML externe
 * (donc pas de fichier .tflite à télécharger : tout tourne 100% hors-ligne).
 *
 * Principe : pour chaque trame de son, on calcule l'énergie du signal dans
 * plusieurs bandes de fréquences réparties sur l'échelle Mel (comme le fait
 * l'oreille humaine), puis on prend le log. On obtient un vecteur qui
 * caractérise le timbre de la voix. On fait ensuite la moyenne sur toutes
 * les trames "voisées" (où quelqu'un parle réellement) pour obtenir
 * l'empreinte vocale globale (le "voiceprint").
 *
 * ⚠️ Ce n'est PAS un système de reconnaissance biométrique de qualité
 * industrielle : c'est volontairement simple pour rester 100% embarqué et
 * sans dépendance. Prévoyez un seuil de similarité pas trop strict et
 * testez / réenregistrez si les faux positifs/négatifs sont trop fréquents.
 */
object VoiceFeatureExtractor {

    const val SAMPLE_RATE = 16000
    const val FRAME_SIZE = 512          // ~32ms à 16kHz, puissance de 2 pour la FFT
    const val FRAME_STEP = 256          // 50% de recouvrement
    const val NUM_MEL_BANDS = 24
    const val FEATURE_DIM = NUM_MEL_BANDS

    private val melFilters: Array<FloatArray> by lazy { buildMelFilterbank() }

    /** Convertit un buffer audio PCM16 en vecteur de caractéristiques moyen. */
    fun extractAverageEmbedding(pcm: ShortArray): FloatArray {
        val frames = frameCount(pcm.size)
        if (frames == 0) return FloatArray(FEATURE_DIM)

        val sum = FloatArray(FEATURE_DIM)
        var voicedFrames = 0

        for (f in 0 until frames) {
            val start = f * FRAME_STEP
            val frame = FloatArray(FRAME_SIZE)
            var energy = 0.0
            for (i in 0 until FRAME_SIZE) {
                val sampleIdx = start + i
                val s = if (sampleIdx < pcm.size) pcm[sampleIdx] / 32768f else 0f
                // Fenêtre de Hamming pour réduire les artefacts spectraux
                val w = (0.54 - 0.46 * cos(2.0 * PI * i / (FRAME_SIZE - 1))).toFloat()
                frame[i] = s * w
                energy += (s * s)
            }

            // Détection d'activité vocale très simple : on ignore les trames trop silencieuses
            val rms = sqrt(energy / FRAME_SIZE)
            if (rms < 0.01) continue

            val spectrum = SimpleFFT.magnitudeSpectrum(frame)
            val melEnergies = applyMelFilters(spectrum)
            for (b in 0 until FEATURE_DIM) {
                sum[b] += ln(melEnergies[b] + 1e-6f)
            }
            voicedFrames++
        }

        if (voicedFrames == 0) return FloatArray(FEATURE_DIM)
        for (b in 0 until FEATURE_DIM) sum[b] /= voicedFrames
        return normalize(sum)
    }

    fun isSpeech(pcm: ShortArray, rmsThreshold: Float = 0.015f): Boolean {
        var energy = 0.0
        for (s in pcm) {
            val v = s / 32768f
            energy += v * v
        }
        val rms = sqrt(energy / pcm.size).toFloat()
        return rms > rmsThreshold
    }

    private fun frameCount(totalSamples: Int): Int {
        if (totalSamples < FRAME_SIZE) return 0
        return 1 + (totalSamples - FRAME_SIZE) / FRAME_STEP
    }

    private fun applyMelFilters(spectrum: FloatArray): FloatArray {
        val out = FloatArray(NUM_MEL_BANDS)
        for (b in 0 until NUM_MEL_BANDS) {
            var sum = 0f
            val filter = melFilters[b]
            for (i in filter.indices) sum += filter[i] * spectrum[i]
            out[b] = sum
        }
        return out
    }

    private fun normalize(vec: FloatArray): FloatArray {
        var norm = 0f
        for (v in vec) norm += v * v
        norm = sqrt(norm)
        if (norm < 1e-6f) return vec
        return FloatArray(vec.size) { vec[it] / norm }
    }

    private fun hzToMel(hz: Double) = 2595.0 * log10(1.0 + hz / 700.0)
    private fun melToHz(mel: Double) = 700.0 * (10.0.pow(mel / 2595.0) - 1.0)

    private fun buildMelFilterbank(): Array<FloatArray> {
        val numBins = FRAME_SIZE / 2
        val minMel = hzToMel(0.0)
        val maxMel = hzToMel(SAMPLE_RATE / 2.0)
        val melPoints = DoubleArray(NUM_MEL_BANDS + 2) { i ->
            minMel + i * (maxMel - minMel) / (NUM_MEL_BANDS + 1)
        }
        val hzPoints = melPoints.map { melToHz(it) }
        val binPoints = hzPoints.map { (it * FRAME_SIZE / SAMPLE_RATE).roundToInt().coerceIn(0, numBins - 1) }

        return Array(NUM_MEL_BANDS) { m ->
            val filter = FloatArray(numBins)
            val left = binPoints[m]
            val center = binPoints[m + 1]
            val right = binPoints[m + 2]
            for (k in left until center) {
                if (center != left) filter[k] = ((k - left).toFloat() / (center - left))
            }
            for (k in center until right) {
                if (right != center) filter[k] = ((right - k).toFloat() / (right - center))
            }
            filter
        }
    }
}
